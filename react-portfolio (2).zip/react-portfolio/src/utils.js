export const getImageUrl = (path) => {
  return path ? `/src/assets/${path.replace(/^\/assets\//, '')}` : "";
};