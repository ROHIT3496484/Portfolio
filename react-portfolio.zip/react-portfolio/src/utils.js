export const getImageUrl = (path) => {
  return path ? `/assets/${path.replace(/^\/assets\//, '')}` : "";
};